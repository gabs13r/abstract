---
id: 2
image: './image.jpg'
large: './large.jpg'
name: 'Robert Doe'
profession: 'Software Developer'
text: 'Sed facilisis magna turpis. Nulla id elit quis quam sodales cursus. Quisque tellus neque, consequat fringilla consequat eget, consequat eget elit.Sed hendrerit velit sed ante vestibulum consequat.'
---