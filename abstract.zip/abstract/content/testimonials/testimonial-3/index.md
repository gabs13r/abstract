---
id: 3
image: './image.jpg'
large: './large.jpg'
name: 'John Doe'
profession: 'Engineer'
text: 'Interdum et malesuada fames ac ante ipsum primis in faucibus. Proin mattis sit amet tortor non facilisis. Etiam imperdiet fringilla ullamcorper. Suspendisse finibus ipsum ut tellus feugiat, quis vehicula ligula lacinia.'
---