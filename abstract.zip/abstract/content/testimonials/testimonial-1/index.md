---
id: 1
image: './image.jpg'
large: './large.jpg'
name: 'John Doe'
profession: 'Software Engineer'
text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vel est eu tortor porttitor congue. Praesent finibus eleifend mi, eu dictum est scelerisque ut. Nulla sed nulla sed tellus feugiat dignissim a pulvinar sem.'
---