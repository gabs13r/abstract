---
id: 5
image: './image.jpg'
name: "Brian Miller"
profession: "Junior Developer"
facebook: "https://www.facebook.com/"
twitter: "https://www.twitter.com/"
linkedin: "https://www.linkedin.com/"
github: "https://github.com/"
---
