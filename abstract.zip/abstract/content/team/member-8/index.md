---
id: 8
image: './image.jpg'
name: "Stephen Brice"
profession: "Angular Developer"
facebook: "https://www.facebook.com/"
twitter: "https://www.twitter.com/"
linkedin: "https://www.linkedin.com/"
github: "https://github.com/"
---
