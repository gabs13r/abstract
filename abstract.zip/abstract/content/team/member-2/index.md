---
id: 2
image: './image.jpg'
name: "John Doe"
profession: "React Developer"
facebook: "https://www.facebook.com/"
twitter: "https://www.twitter.com/"
linkedin: "https://www.linkedin.com/"
github: "https://github.com/"
---
