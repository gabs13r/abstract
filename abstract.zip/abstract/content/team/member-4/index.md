---
id: 4
image: './image.jpg'
name: "John Doe"
profession: "Software Architect"
facebook: "https://www.facebook.com/"
twitter: "https://www.twitter.com/"
linkedin: "https://www.linkedin.com/"
github: "https://github.com/"
---
