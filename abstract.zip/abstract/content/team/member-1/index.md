---
id: 1
image: './image.jpg'
name: "Robert Doe"
profession: "Angular Developer"
facebook: "https://www.facebook.com/"
twitter: "https://www.twitter.com/"
linkedin: "https://www.linkedin.com/"
github: "https://github.com/"
---
