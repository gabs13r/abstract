---
id: 3
image: './image.jpg'
name: "Richard Smith"
profession: "Finance Expert"
facebook: "https://www.facebook.com/"
twitter: "https://www.twitter.com/"
linkedin: "https://www.linkedin.com/"
github: "https://github.com/"
---
